import axios from 'axios';
import { incrementRequestCount } from '../../../lib/db';

export default async function handler(req, res) {
    const { url } = req.query;
    if (!url || !/^https?:\/\/open\.spotify\.com\/track\/[a-zA-Z0-9]+/i.test(url)) {
        return res.status(400).json({ success: false, error: 'Bad Request: Invalid or missing Spotify track URL' });
    }

    try {
        const baseHeaders = {
            'accept-encoding': 'gzip, deflate, br, zstd',
        };

        // Step 1: Get Cookie & Token
        const homepageRes = await axios.get('https://spotidown.app/', {
            headers: baseHeaders,
            withCredentials: true,
        });

        const html = homepageRes.data;
        const tokenName = html.match(/input name="(.+?)"/)?.[1];
        const tokenValue = html.match(/type="hidden" value="(.+?)"/)?.[1];
        const cookie = homepageRes.headers['set-cookie']?.[0]?.split('; ')?.[0];

        if (!tokenName || !tokenValue || !cookie) {
            return res.status(500).json({ success: false, error: 'Failed to retrieve token or cookie from homepage' });
        }

        // Step 2: Submit URL for action
        const actionRes = await axios.post('https://spotidown.app/action', new URLSearchParams({
            url,
            [tokenName]: tokenValue,
            'g-recaptcha-response': ''
        }), {
            headers: {
                ...baseHeaders,
                'referer': 'https://spotidown.app/',
                'cookie': cookie,
            }
        });

        if (actionRes.data?.error) {
            return res.status(500).json({ success: false, error: 'Action step failed: ' + JSON.stringify(actionRes.data) });
        }

        const actionHtml = actionRes.data.data;
        const image = actionHtml.match(/<img src="(.+?)"/)?.[1];
        const data = actionHtml.match(/name="data" value=(?:"|')(.+?)(?:"|')/)?.[1];
        const base = actionHtml.match(/name="base" value="(.+?)"/)?.[1];
        const token = actionHtml.match(/name="token" value="(.+?)"/)?.[1];

        if (!data || !base || !token) {
            return res.status(500).json({ success: false, error: 'Missing data, base or token in action response' });
        }

        // Step 3: Final track info
        const trackRes = await axios.post('https://spotidown.app/action/track', new URLSearchParams({
            data,
            base,
            token
        }), {
            headers: {
                ...baseHeaders,
                'referer': 'https://spotidown.app/',
                'cookie': cookie,
            }
        });

        if (trackRes.data?.error) {
            return res.status(500).json({ success: false, error: 'Track step failed: ' + JSON.stringify(trackRes.data) });
        }

        const trackHtml = trackRes.data.data;
        const title = trackHtml.match(/title="(.+?)">/)?.[1] || '(no title)';
        const artist = trackHtml.match(/<span>(.+?)<\/span>/)?.[1] || '(no artist)';
        const audioUrl = trackHtml.match(/href="(.+?)" class="abutton is-success is-fullwidth "/)?.[1];
        const albumArtUrl = trackHtml.match(/;" href="(.+?)" class="abutton is-success is-fullwidth">/)?.[1] || image;

        if (!audioUrl) {
            return res.status(500).json({ success: false, error: 'Failed to extract audio URL' });
        }

        await incrementRequestCount();

        return res.status(200).json({
            success: true,
            title,
            artist,
            audioUrl,
            albumArtUrl
        });

    } catch (error) {
        return res.status(500).json({
            success: false,
            error: 'Internal Server Error: ' + error.message
        });
    }
}